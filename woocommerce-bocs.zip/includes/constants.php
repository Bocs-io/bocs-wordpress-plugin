<?php

define('BOCS_API_KEY', 'API KEY :');
// define('BOCS_API_URL', 'https://hhxamjuhk2.execute-api.ap-southeast-2.amazonaws.com/test');
// define('BOCS_API_URL', 'https://api.bocs.io/test');
define('BOCS_API_URL_COLLECTIONS', '/woocommerce/collections');
define('BOCS_CANCEL_SUBSCRIPTIONS', 'CANCEL SUBSCRIPTIONS:');
define('BOCS_COLLECTIONS_DETAIL', 'COLLECTIONS DETAIL:');
define('BOCS_SETTINGS', 'Bocs Settings');
define('BOCS_TITLE', 'Bocs');