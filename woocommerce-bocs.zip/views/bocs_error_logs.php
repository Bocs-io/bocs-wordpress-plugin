<div class="wrap">
    <h2>Error Logs</h2>
<?php
$table = new Error_Logs_List_Table();
$table->prepare_items();
$table->display();
?>
</div>