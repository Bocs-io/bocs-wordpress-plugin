v0.0.43 10/03/2023
* Added icon on the description
* Edit Page, showing the selected/saved

v0.0.42 09/29/2023
* New UI added on Gutenburg Editor

v0.0.41 09/21/2023
* Fix error when both Gutenburg and sidebar is loading

v0.0.40 09/18/2023
* Fix error when creating a customer via API

v0.0.38 09/15/2023
* Redirects to the checkout page

v0.0.37 09/14/2023
* Added support for editors using ACF

v0.0.36 09/13/2023
* Added the Fixed type

v0.0.35 08/16/2023
* Added filter on the admin users list for options bocs or wordpress or both

v0.0.34 08/11/2023
* Added Source (Wordpress or Bocs) column on Admin Users List

v0.0.33 08/04/2023
* Moved the sync logs and sync modules under settings as tabs

v0.0.32 08/01/2023
* Fixes on the sync end

v0.0.31 07/31/2023
* create/register new user log/sync

v0.0.30 07/30/2023
* log's context update to json encoded array
* added details on the table display

v0.0.29 07/27/2023
* Endpoint ID fix
* Added logs on the syncs 
* Added module and id on logs

v0.0.28 07/26/2023
* Updated the endpoint for the sync
* Removed the logs related code due to errors

v0.0.27 07/24/2023
* moved the position of the menu
* added sample error log menu and content

v0.0.26 07/24/2023
* Fix when the bocs' contact id is outdated or not on the same Bocs Account

v0.0.25 07/20/2023
* When user his own profile - trigger sync

v0.0.24 07/18/2023
* Added synced when a user is edited

v0.0.23 07/13/2023
* saving on the bocs widget editor fix

v0.0.22 07/12/2023
* added radio input on the bocs widget editor
* remove highlight to non-active option

v0.0.21 07/11/2023
* added auto add bocs keys needed

v0.0.20 07/07/2023
* added the working plugin updater

v0.0.19 07/06/2023
* fix widget for the collections list
* added wordpress updater

v0.0.18 07/03/2023
* added collections list

v0.0.17 06/29/2023
* added the list of subscriptions and showing under the menu
* added the discount upon checkout

v0.0.16 06/29/2023
* add subscription to bocs app
* add new subscription to wordpress site - tables only

v0.0.15 06/28/2023
* fixes on the cart checkout
* added logo on the menu

v0.0.14 06/27/2023
* added creation of the bocs and products if not synced on checkout
* if the order is paid or processing, it will create an order and subscription on bocs end
* fix not showing list of bocs