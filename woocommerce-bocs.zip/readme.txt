v0.0.22 07/12/2023
* added radio input on the bocs widget editor
* remove highlight to non-active option

v0.0.21 07/11/2023
* added auto add bocs keys needed

v0.0.20 07/07/2023
* added the working plugin updater

v0.0.19 07/06/2023
* fix widget for the collections list
* added wordpress updater

v0.0.18 07/03/2023
* added collections list

v0.0.17 06/29/2023
* added the list of subscriptions and showing under the menu
* added the discount upon checkout

v0.0.16 06/29/2023
* add subscription to bocs app
* add new subscription to wordpress site - tables only

v0.0.15 06/28/2023
* fixes on the cart checkout
* added logo on the menu

v0.0.14 06/27/2023
* added creation of the bocs and products if not synced on checkout
* if the order is paid or processing, it will create an order and subscription on bocs end
* fix not showing list of bocs